# Quartz

## [3.5.0](https://github.com/Nevcairiel/Quartz/tree/3.5.0) (2019-08-27)
[Full Changelog](https://github.com/Nevcairiel/Quartz/compare/3.4.1...3.5.0)

- Update pkgmeta URLs  
- Scale the position offset of the shield as well  
- The not-interruptible shield texture scales with castbar size  
- Add Travis-CI packaging support  
- Update channeling abilities for classic  
- Classic support for personal cast bars, no Target cast bars, no Tradeskill (yet)  
