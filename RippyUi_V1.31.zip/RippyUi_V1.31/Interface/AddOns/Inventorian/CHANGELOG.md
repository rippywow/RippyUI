# Inventorian

## [1.13.2.2](https://github.com/Nevcairiel/Inventorian/tree/1.13.2.2) (2019-08-15)
[Full Changelog](https://github.com/Nevcairiel/Inventorian/compare/1.13.2.1...1.13.2.2)

- Add keyring support to LibItemCache  
- Add new constants for LuaCheck  
- Fix item quality display  
    SetItemButtonQuality is for bizare reasons disabled on Classic  
