local addon = KuiNameplates
local ele = addon:NewElement('ClassPowers')
