﻿-- turn on or off debugging
MONKEYLIB_DEBUG				= false;
-- global "constants"
MONKEYLIB_VERSION			= "2.9.37";
--MONKEYLIB_TITLE_COLOUR		= { r = 1.0, g = 0.5, b = 0 };
MONKEYLIB_TITLE_COLOUR		= { r = 0.12, g = 0.55, b = 0.76 };