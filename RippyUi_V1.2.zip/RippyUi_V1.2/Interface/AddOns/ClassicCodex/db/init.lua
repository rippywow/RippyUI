CodexDB = {
  ["units"] = {},
  ["objects"] = {},
  ["quests"] = {},
  ["items"] = {},
}
  