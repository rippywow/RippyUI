--[[	RealMobHealth BlizzardUI GameTooltip Mod
	by SDPhantom
	https://www.wowinterface.com/forums/member.php?u=34145	]]
------------------------------------------------------------------

local AddOn=select(2,...);
local RMH=RealMobHealth;

------------------
--[[	Locale	]]
------------------
local LocaleStrings={
	enUS={
		"Unit health is recorded.";
		"Unit health is blacklisted.";
		"Unit health is missing.";
	};
}

LocaleStrings=LocaleStrings[GetLocale()] or LocaleStrings.enUS;

----------------------------------
--[[	GameTooltip Hook	]]
----------------------------------
GameTooltip:HookScript("OnTooltipSetUnit",function(self)
	local _,unit=self:GetUnit();
	if unit and UnitCanAttack("player",unit) and RMH.IsUnitMob(unit) then
		if RMH.UnitHasHealthData(unit) then self:AddLine(LocaleStrings[1],0,1,0);
		elseif RMH.IsUnitBlacklisted(unit) then self:AddLine(LocaleStrings[2],0.5,0.5,0.5);
		else self:AddLine(LocaleStrings[3],1,0,0); end
	end
end);
