--[[	RealMobHealth BlizzardUI TargetFrame Mod
	by SDPhantom
	https://www.wowinterface.com/forums/member.php?u=34145	]]
------------------------------------------------------------------

local AddOn=select(2,...);
local RMH=RealMobHealth;

----------------------------------
--[[	Setup TargetFrame	]]
----------------------------------
local function SetupUFStatusBarText(parent,bar)--	Create strings for TextStatusBars
	local text,left,right=	parent:CreateFontString(nil,"OVERLAY","TextStatusBarText")
				,parent:CreateFontString(nil,"OVERLAY","TextStatusBarText")
				,parent:CreateFontString(nil,"OVERLAY","TextStatusBarText");

	bar.TextString,bar.LeftText,bar.RightText=text,left,right;
	text:SetPoint("CENTER",bar,"CENTER",0,0);
	left:SetPoint("LEFT",bar,"LEFT",2,0);
	right:SetPoint("RIGHT",bar,"RIGHT",-2,0);
end

--	TargetFrame doesn't have FontStrings for the health and mana bars
SetupUFStatusBarText(TargetFrameTextureFrame,TargetFrameManaBar);
SetupUFStatusBarText(TargetFrameTextureFrame,TargetFrameHealthBar);

----------------------------------
--[[	Hooks & Callbacks	]]
----------------------------------
--	Hook healthbars
local HookedBars={};
hooksecurefunc("UnitFrameHealthBar_Update",function(self,unit)
	if not HookedBars[self] then
		HookedBars[self]=true;
		TextStatusBar_UpdateTextString(self);--	Runs our hook below
	end
end);

--	Replace health text with our own values
local TextStatusBar_UpdateTextStringWithValues=TextStatusBar_UpdateTextStringWithValues;--	Local cache so we don't run our own hook indefinitely
hooksecurefunc("TextStatusBar_UpdateTextStringWithValues",function(bar,txt,val,min,max)
	if HookedBars[bar] and bar.unit then--	Run only on bars we've noted, can run on uninitialized ones
		local val,max,valspec,maxspec=RMH.GetUnitHealth(bar.unit,true);--	Returns 3 and 4 are nil if we don't have enough data for speculation (Don't update in that case)
		if valspec~=nil or maxspec~=nil then TextStatusBar_UpdateTextStringWithValues(bar,txt,val,min,max); end
	end
end);

--	Health update callback
RMH.RegisterHealthUpdateCallback(function(creaturekey)
	for bar in next,HookedBars do
		if bar.unit and (not creaturekey or creaturekey==RMH.GetUnitCreatureKey(bar.unit)) then TextStatusBar_UpdateTextString(bar); end--	Re-run our hook
	end
end);
