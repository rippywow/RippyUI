Real Mob Health - Blizzard UI Tweaks
by SDPhantom
https://www.wowinterface.com/forums/member.php?u=34145
===============================================================================

All Rights Reserved - Use at your own risk
UnZip contents into the "Interface\AddOns" folder in your WoW instalation directory

===============================================================================

Versions:
1.0	(2019-06-05)
	-Split code from Real Mob Health
	-GameTooltip hook now only runs if the unit is attackable

Internal	(2019-05-19)
	-Classic release
	-TargetFrame and Nameplates show text values for health, TargetFrame also shows mana/rage/energy
	-Gametooltip shows which mobs have had their health recorded
