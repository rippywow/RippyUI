--[[	RealMobHealth BlizzardUI NamePlates Mod
	by SDPhantom
	https://www.wowinterface.com/forums/member.php?u=34145	]]
------------------------------------------------------------------

local AddOn=select(2,...);
local RMH=RealMobHealth;

----------------------------------
--[[	Hooks & Callbacks	]]
----------------------------------
--	Create health FontStrings
local HealthText={};
hooksecurefunc(NamePlateDriverFrame,"OnNamePlateCreated",function(self,base)--	Hook Nameplate creation
	local unitframe=base.UnitFrame;

	local health=unitframe.healthBar:CreateFontString(nil,"OVERLAY",FontName);--"NumberFontNormalSmall");
	health:SetFont("Fonts\\ArialN.ttf",10,"THICKOUTLINE");--	Fonts are easier to read when made from scratch rather than resizing an inherited one
	health:SetPoint("LEFT",0,0);
	health:SetTextColor(0,1,0);

	HealthText[unitframe]=health;
end);

--	Updates text
local function UpdateHealthText(unitframe)
	local health=RMH.GetUnitHealth(unitframe.displayedUnit,true);
	HealthText[unitframe]:SetText(AddOn.AbbreviateNumber(health));
end

--	Hook text set
hooksecurefunc("CompactUnitFrame_UpdateHealth",function(self)--	This is a shared function with other UnitFrames
	if not HealthText[self] then return; end
	UpdateHealthText(self);
end);

--	Health update callback
RMH.RegisterHealthUpdateCallback(function(creaturekey)
	for unitframe in next,HealthText do
		if unitframe.displayedUnit and (not creaturekey or creaturekey==RMH.GetUnitCreatureKey(unitframe.displayedUnit)) then
			UpdateHealthText(unitframe);
		end
	end
end);
