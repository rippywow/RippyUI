# Lorti UI Classic. 

I'm going to abandon this project. I dont have the time or will to keep this maintained. There are other addons out there that do the same thing, but are coded and maintained better than this.

**IF ANYONE WANTS TO TAKE OVER THIS PROJECT, PM ME ON DISCORD AND I'LL TRANSFER THE PROJECT TO YOU**

Discord: Chordsy#8773

Below are some other addons that do pretty much the same thing.
- https://github.com/obble/modui_classic
- https://www.wowinterface.com/downloads/info25026-AbyssUIClassic.html
