--[[	RealMobHealth Creature Blacklist
	by SDPhantom
	https://www.wowinterface.com/forums/member.php?u=34145	]]
------------------------------------------------------------------

local CreatureOverrides=select(2,...).CreatureOverrides;

--	Usage:	CreatureOverrides[CreatureID]=MaxHealth
--		[string] CreatureKey	If string, must be of format "<CreatureID>-<Level>" for normal mobs and "<CreatureID>" for raid bosses (Use the later for blacklisting)
--		[number] MaxHealth	Max health of creature (Creature is blacklisted if zero)

CreatureOverrides["5873"]=0;--	Stoneskin Totem
CreatureOverrides["2630"]=0;--	Earthbind Totem
CreatureOverrides["3579"]=0;--	Stoneclaw Totem
CreatureOverrides["2523"]=0;--	Searing Totem
CreatureOverrides["5874"]=0;--	Strength of Earth Totem
CreatureOverrides["5879"]=0;--	Fire Nova Totem
CreatureOverrides["5919"]=0;--	Stoneskin Totem II
CreatureOverrides["3911"]=0;--	Stoneclaw Totem II
CreatureOverrides["5913"]=0;--	Tremor Totem
CreatureOverrides["3527"]=0;--	Healing Stream Totem
CreatureOverrides["3902"]=0;--	Searing Totem II
CreatureOverrides["6110"]=0;--	Fire Nova Totem II
CreatureOverrides["5923"]=0;--	Poison Cleansing Totem
CreatureOverrides["5926"]=0;--	Frost Resistance Totem
CreatureOverrides["5920"]=0;--	Stoneskin Totem III
CreatureOverrides["5921"]=0;--	Strength of Earth Totem II
CreatureOverrides["5929"]=0;--	Magma Totem
CreatureOverrides["3573"]=0;--	Mana Spring Totem
CreatureOverrides["5927"]=0;--	Fire Resistance Totem
CreatureOverrides["5950"]=0;--	Flametongue Totem
CreatureOverrides["3912"]=0;--	Stoneclaw Totem III
CreatureOverrides["5925"]=0;--	Grounding Totem
CreatureOverrides["3906"]=0;--	Healing Stream Totem II
CreatureOverrides["7467"]=0;--	Nature Resistance Totem
CreatureOverrides["3903"]=0;--	Searing Totem III
CreatureOverrides["6111"]=0;--	Fire Nova Totem III
CreatureOverrides["6112"]=0;--	Windfury Totem
CreatureOverrides["3968"]=0;--	Sentry Totem
CreatureOverrides["7366"]=0;--	Stoneskin Totem IV
CreatureOverrides["7464"]=0;--	Magma Totem II
CreatureOverrides["7414"]=0;--	Mana Spring Totem II
CreatureOverrides["9687"]=0;--	Windwall Totem
CreatureOverrides["5924"]=0;--	Disease Cleansing Totem
CreatureOverrides["6012"]=0;--	Flametongue Totem II
CreatureOverrides["7412"]=0;--	Frost Resistance Totem II
CreatureOverrides["3913"]=0;--	Stoneclaw Totem IV
CreatureOverrides["5922"]=0;--	Strength of Earth Totem III
CreatureOverrides["3907"]=0;--	Healing Stream Totem III
CreatureOverrides["3904"]=0;--	Searing Totem IV
CreatureOverrides["7844"]=0;--	Fire Nova Totem IV
CreatureOverrides["7424"]=0;--	Fire Resistance Totem II
CreatureOverrides["7486"]=0;--	Grace of Air Totem
CreatureOverrides["7483"]=0;--	Windfury Totem II
CreatureOverrides["7468"]=0;--	Nature Resistance Totem II
CreatureOverrides["7367"]=0;--	Stoneskin Totem V
CreatureOverrides["7465"]=0;--	Magma Totem III
CreatureOverrides["7415"]=0;--	Mana Spring Totem III
CreatureOverrides["9688"]=0;--	Windwall Totem II
CreatureOverrides["7423"]=0;--	Flametongue Totem III
CreatureOverrides["11100"]=0;--	Mana Tide Totem II
CreatureOverrides["7398"]=0;--	Stoneclaw Totem V
CreatureOverrides["3908"]=0;--	Healing Stream Totem IV
CreatureOverrides["7400"]=0;--	Searing Totem V
CreatureOverrides["15803"]=0;--	Tranquil Air Totem
CreatureOverrides["7845"]=0;--	Fire Nova Totem V
CreatureOverrides["7403"]=0;--	Strength of Earth Totem IV
CreatureOverrides["7484"]=0;--	Windfury Totem III
CreatureOverrides["7413"]=0;--	Frost Resistance Totem III
CreatureOverrides["7368"]=0;--	Stoneskin Totem VI
CreatureOverrides["7487"]=0;--	Grace of Air Totem II
CreatureOverrides["7466"]=0;--	Magma Totem IV
CreatureOverrides["7416"]=0;--	Mana Spring Totem IV
CreatureOverrides["9689"]=0;--	Windwall Totem III
CreatureOverrides["7425"]=0;--	Fire Resistance Totem III
CreatureOverrides["10557"]=0;--	Flametongue Totem IV
CreatureOverrides["11101"]=0;--	Mana Tide Totem III
CreatureOverrides["7399"]=0;--	Stoneclaw Totem VI
CreatureOverrides["15463"]=0;--	Grace of Air Totem III
CreatureOverrides["3909"]=0;--	Healing Stream Totem V
CreatureOverrides["7469"]=0;--	Nature Resistance Totem III
CreatureOverrides["7402"]=0;--	Searing Totem VI
CreatureOverrides["15464"]=0;--	Strength of Earth Totem V
