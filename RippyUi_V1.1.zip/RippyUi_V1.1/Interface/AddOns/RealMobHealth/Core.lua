--[[	RealMobHealth
	by SDPhantom
	https://www.wowinterface.com/forums/member.php?u=34145	]]
------------------------------------------------------------------

local Name,AddOn=...;
_G[Name]=AddOn;

--------------------------
--[[	External Tables	]]
--------------------------
local CreatureOverrides=AddOn.CreatureOverrides or {};--	Blacklisted keys have zero health
AddOn.CreatureOverrides=CreatureOverrides;--	Support adding values after loading

--------------------------
--[[	SavedVar	]]
--------------------------
local HealthCache={};
RealMobHealth_CreatureHealthCache=HealthCache;

--------------------------
--[[	Local Variables	]]
--------------------------
local KeyCache={};--	Links GUID to creature key
local DamageCache={};--	Links GUID to damage taken
local HealthUpdateCallbacks={};

local DamageSyncThreshold=0.02--	Switch to speculative mode if damage gets this far out of sync (As percent)
local MobUnitTypes={--	Lookup of mob unit types from GUID
	Creature=true;--	Mob/NPC
	Vignette=true;--	Rares
}

----------------------------------
--[[	Local References	]]
----------------------------------
local assert=assert;
local CombatLogGetCurrentEventInfo=CombatLogGetCurrentEventInfo;
local geterrorhandler=geterrorhandler;
local ipairs=ipairs;
local math_abs=math.abs;
local math_ceil=math.ceil;
local math_max=math.max;
local pcall=pcall;
local string_format=string.format;
local string_gsub=string.gsub;
local string_match=string.match;
local table_insert=table.insert;
local table_remove=table.remove;
local tonumber=tonumber;
local tostring=tostring;
local type=type;
local UnitClassification=UnitClassification;
local UnitGUID=UnitGUID;
local UnitHealth=UnitHealth;
local UnitHealthMax=UnitHealthMax;
local UnitLevel=UnitLevel;

----------------------------------
--[[	Lua extension functions	]]
----------------------------------
local function table_find(tbl,val)--	Find value in indexed table
	for k,v in ipairs(tbl) do if v==val then return k; end end
end

----------------------------------
--[[	Helper Functions	]]
----------------------------------
--	GUID Format
--	[Unit type]-0-[server ID]-[instance ID]-[zone UID]-[ID]-[spawn UID]
--	Unit Types:	Creature, GameObject, Pet, Vehicle, Vignette
--	Player:	Player-[server ID]-[player UID]

local FireHealthUpdateCallbacks; do--	function(guid,creaturekey,maxhealth)	xpcall()'d dispatcher for accurate error messages that doesn't interrupt caller
	local Func,CreatureKey,MaxHealth;--	Args to pass through
	local function HealthUpdateDispatcher() return Func(CreatureKey,MaxHealth); end

	function FireHealthUpdateCallbacks(creaturekey,maxhealth)
		CreatureKey,MaxHealth=creaturekey,maxhealth;--	Update upvalues
		local hnd=geterrorhandler();--	AddOns can change this at any time
		for _,func in ipairs(HealthUpdateCallbacks) do Func=func; xpcall(HealthUpdateDispatcher,hnd); end--	Dispatch to callbacks (Note: xpcall doesn't support sending args, we have to do it this way)
	end
end

local function CreaturePassesBlacklist(creaturekey) local max=CreatureOverrides[string_match(creaturekey,"^%d+")]; return max==nil or max>0; end--	Blacklist entries require level omission and health set to zero

local function GetCreatureFromGUID(guid)--	Extracts creature type and ID from GUID
	local utype,creatureid=string_match(guid,"^(.-)%-0%-%d+%-%d+%-%d+%-(%d+)%-%x+$");
	return utype,creatureid and tonumber(creatureid);--	Convert CreatureID to number
end

local function GetUnitCreatureKey(unit)
	local guid=UnitGUID(unit);
	if not guid then return; end--	Unit doesn't exist

	local utype,creatureid=GetCreatureFromGUID(guid);
	if not (utype and MobUnitTypes[utype]) then return; end--	Unit not mob

	if UnitClassification(unit)=="worldboss" then return tostring(creatureid);--	World Bosses have no level, return as raw CreatureID
	else
		local level=UnitLevel(unit);--	UnitLevel() returns -1 for units with hidden levels (Skull/??)
		if level and level>0 then return string_format("%d-%d",creatureid,level); end
	end
end

local function IsMobGUID(guid)
	if not guid then return false; end
	local utype=GetCreatureFromGUID(guid);
	return (utype and MobUnitTypes[utype]) or false;
end

local function GetDamageFromEvent(...)--	Process CLE into relevant GUID, damage taken, and overkill/overheal flag
	local _,event=...;
	local prefix,suffix=string_match(event,"^([^_]+)_(.-)$");

--	Convert SPELL_PERIODIC and SPELL_BUILDING into just SPELL (Previous line actually puts PERIODIC_ and BUILDING_ in suffix)
	if prefix=="SPELL" then suffix=string_gsub(string_gsub(suffix,"^PERIODIC_",""),"^BUILDING_",""); end

--	Convert these event aliases
	if event=="DAMAGE_SHIELD" or event=="DAMAGE_SPLIT" then prefix,suffix="SPELL","DAMAGE"; end

--	Capture relevant args
	local guid,amount,over;
	if prefix=="SWING" then			_,_,_,_,_,_,_,guid,_,_,_,amount,over=...;
	elseif prefix=="ENVIRONMENTAL" then	_,_,_,_,_,_,_,guid,_,_,_,_,amount,over=...;
	elseif prefix=="RANGE" then		_,_,_,_,_,_,_,guid,_,_,_,_,_,_,amount,over=...;
	elseif prefix=="SPELL" then		_,_,_,_,_,_,_,guid,_,_,_,_,_,_,amount,over=...;
	elseif event=="UNIT_DIED" or event=="UNIT_DESTROYED" or event=="UNIT_DISSIPATES" then
		_,_,_,_,_,_,_,guid=...;
		return guid,0,true;--	Unit dead, send zero change and flag overkill
	end

	if guid and amount and (suffix=="DAMAGE" or suffix=="HEAL") then
--		Normalize damage to be positive and heals negative (We are recording damage taken)
		amount=amount-math_max(over,0);--	Remove overkill/overheal from damage/heal amount
		return guid,suffix=="DAMAGE" and amount or -amount,over>0;--	overkill/overheal is -1 when not present
	end
end

--------------------------
--[[	API Functions	]]
--------------------------
AddOn.GetUnitCreatureKey=GetUnitCreatureKey;
AddOn.IsMobGUID=IsMobGUID;
function AddOn.IsUnitMob(unit) return IsMobGUID(UnitGUID(unit)); end

function AddOn.RegisterHealthUpdateCallback(callback)
	assert(type(callback)=="function","Callback must be a function");
	if table_find(HealthUpdateCallbacks,callback) then return; end--	Return if already registered
	table_insert(HealthUpdateCallbacks,callback);
end

function AddOn.UnregisterHealthUpdateCallback(callback)
	assert(type(callback)=="function","Callback must be a function");
	local index=table_find(HealthUpdateCallbacks,callback);--	Find function
	if index then table_remove(HealthUpdateCallbacks,index); end--	Remove function
end

function AddOn.IsHealthUpdateCallbackRegistered(callback)
	assert(type(callback)=="function","Callback must be a function");
	return table_find(HealthUpdateCallbacks,callback) and true or false;--	Cast to boolean
end

function AddOn.IsUnitBlacklisted(unit)
	local creaturekey=GetUnitCreatureKey(unit);
	return creaturekey and not CreaturePassesBlacklist(creaturekey);
end

function AddOn.GetUnitHealth(unit,speculate)
	local guid=UnitGUID(unit);
	if guid then--	Need a unit to continue
		local naturalcurrent,naturalmax=UnitHealth(unit),UnitHealthMax(unit);--	Save these as default values if we fail to return anything
		local creaturekey=GetUnitCreatureKey(unit);
		if creaturekey and CreaturePassesBlacklist(creaturekey) then--	We need a CreatureKey to continue
			local percent=naturalmax>0 and naturalcurrent/naturalmax or 0;--	Right now, health scales 1-100, automaticly adjusts for different scale if this changes
			local damage=DamageCache[guid] or 0;--	Default to zero damage
			local max=CreatureOverrides[creaturekey] or HealthCache[creaturekey];

			if max then--	Data found, no need to speculate that
				if percent<=0 or percent>=1 then return percent>=1 and max or 0,max,false,false; end--	Unit dead or full health

				local guess=math_ceil(max*percent);--	Calculate from percentage (Less precise)
				if damage<=0 then return guess,max,true,false; end--	No damage recorded

				local current=max-damage;--	Calculate from damage taken
				if math_abs(current-guess)<max*DamageSyncThreshold then return current,max,false,false;--	Damage is within an acceptible range
				else return guess,max,true,false; end--	Damage is out of sync
			elseif speculate and damage>0 and percent<1 then--	Only speculate if allowed and requires damage taken
				max=math_ceil(damage/(1-percent));--	Reverse calculation based on percent health and damage taken
				if percent<=0 then return 0,max,false,true;--	Current health can't be more precise than dead
				else return max-damage,max,true,true; end--	Complete speculation here, precision should improve the more damage a unit takes
			end
		end

		return naturalcurrent,naturalmax,nil,nil;--	Fallback to natural values
	end
end

function AddOn.DeleteUnitHealthData(unit)
	local creaturekey=GetUnitCreatureKey(unit);
	if creaturekey and HealthCache[creaturekey] then
		HealthCache[creaturekey]=nil;--	Delete value
		FireHealthUpdateCallbacks(creaturekey,nil);--	Fire callbacks
	end
end

function AddOn.UnitHasHealthData(unit)
	local creaturekey=GetUnitCreatureKey(unit);
	return ((creaturekey and CreaturePassesBlacklist(creaturekey)) and (CreatureOverrides[creaturekey] or HealthCache[creaturekey])) and true or false;--	Cast to boolean
end

--------------------------
--[[	Debug Commands	]]
--------------------------
hash_ChatTypeInfoList["/RMHDEL"]="REALMOBHEALTH_DELUNIT";
hash_SlashCmdList["/RMHDEL"]=function(msg)
	local unit=msg or "target";
	if AddOn.UnitHasHealthData(unit) then
		AddOn.DeleteUnitHealthData(unit);
		print("Deleted",GetUnitCreatureKey(unit),UnitName(unit));
	else print("Unit not found"); end
end;

do	local LocalCache={};--	For retesting data collection code

	hash_ChatTypeInfoList["/RMHNEW"]="REALMOBHEALTH_NEWCACHE";
	hash_SlashCmdList["/RMHNEW"]=function()
		table.wipe(LocalCache);
		HealthCache=LocalCache;
		FireHealthUpdateCallbacks(nil,nil);
		print("LocalHealthCache created");
	end;

	hash_ChatTypeInfoList["/RMHCLONE"]="REALMOBHEALTH_CLONECACHE";
	hash_SlashCmdList["/RMHCLONE"]=function()
		table.wipe(LocalCache);
		for key,val in pairs(RealMobHealth_CreatureHealthCache) do LocalCache[key]=val; end
		HealthCache=LocalCache;
--		FireHealthUpdateCallbacks(nil,nil);--	Doesn't need to be run, data hasn't changed
		print("LocalHealthCache cloned");
	end;

	hash_ChatTypeInfoList["/RMHRESTORE"]="REALMOBHEALTH_RESTORECACHE";
	hash_SlashCmdList["/RMHRESTORE"]=function()
		HealthCache=RealMobHealth_CreatureHealthCache;
		FireHealthUpdateCallbacks(nil,nil);
		print("LocalHealthCache deleted");
	end;
end

--------------------------
--[[	Event Handler	]]
--------------------------
local EventFrame=CreateFrame("Frame");
EventFrame:RegisterEvent("ADDON_LOADED");
EventFrame:RegisterEvent("PLAYER_LOGOUT");
EventFrame:RegisterEvent("NAME_PLATE_UNIT_ADDED");
EventFrame:RegisterEvent("UPDATE_MOUSEOVER_UNIT");
EventFrame:RegisterEvent("PLAYER_TARGET_CHANGED");
EventFrame:RegisterEvent("UNIT_TARGET");
EventFrame:RegisterEvent("UNIT_HEALTH");
EventFrame:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED");

local function ProcessUnit(unit)--	Called when we're aware of a new/updated unit
	local guid=UnitGUID(unit);
	if guid then
--		Check if mob dead/reset (Clear damage cache)
		local current,max=UnitHealth(unit),UnitHealthMax(unit);
		if (current==0 or current==max) then DamageCache[guid]=nil; end

--		Cache CreatureKey
		if current>0 then--	Dead creatures aren't very useful
			local creaturekey=GetUnitCreatureKey(unit);
			if creaturekey and CreaturePassesBlacklist(creaturekey) then KeyCache[guid]=creaturekey; end--	Save key (Blacklisted creatures have zero health recorded, we still want nil entries to pass this test)
		else KeyCache[guid]=nil; end--	Delete if dead
	end
end

EventFrame:SetScript("OnEvent",function(self,event,...)
	if event=="ADDON_LOADED" and (...)==Name then
		HealthCache=RealMobHealth_CreatureHealthCache;--	Sync upvalue with SavedVar
		self:UnregisterEvent(event);
	elseif event=="PLAYER_LOGOUT" then--	Do this on logout, otherwise other addons won't have a chance to modify the blacklist before culling happens
		for creaturekey in next,HealthCache do
			if not CreaturePassesBlacklist(creaturekey) then HealthCache[creaturekey]=nil; end--	Cull blacklisted values
		end
	elseif event=="NAME_PLATE_UNIT_ADDED" then	ProcessUnit((...));--			Nameplate scan
	elseif event=="UPDATE_MOUSEOVER_UNIT" then	ProcessUnit("mouseover");--		Mouseover scan
							ProcessUnit("mouseovertarget");--	Mouseover target scan
	elseif event=="PLAYER_TARGET_CHANGED" then	ProcessUnit("target");--		Target scan
							ProcessUnit("targettarget");--		Target target scan
	elseif event=="UNIT_TARGET" then		ProcessUnit((...).."target");--		Party/Raid target scan
	elseif event=="UNIT_HEALTH" then		ProcessUnit((...));--			Revalidate in case of reset/death
	elseif event=="COMBAT_LOG_EVENT_UNFILTERED" then
		local guid,damage,isover=GetDamageFromEvent(CombatLogGetCurrentEventInfo());--	Returns nil if event is irrelevant
		if damage and IsMobGUID(guid) then--	Checking damage first returns faster than calling IsMobGUID() on nil
			local total=math_max((DamageCache[guid] or 0)+damage,0);--	Add the damage (Deals with overheal by clamping at zero)
			if isover and damage>=0 then--	If we overkilled, it's a death (damage<0 is overheal)
				if total>0 then--	Unit death event will trigger overkill and damage at zero, if we already wiped the damage cache, don't process again
					local creaturekey=KeyCache[guid];
					if creaturekey and CreaturePassesBlacklist(creaturekey) then--	Check if blacklisted
						if total>(HealthCache[creaturekey] or 0) then
							HealthCache[creaturekey]=total;--	Record with the highest seen damage value (Fixes values from partially-witnessed fights)
							FireHealthUpdateCallbacks(creaturekey,total);--	Fire callbacks
						end
						KeyCache[guid]=nil;--	Delete from key cache
					end
				end
				DamageCache[guid]=nil;--	Delete from damage cache
			else DamageCache[guid]=total; end--	Unit still alive, store new damage value
		end
	end
end);
