Real Mob Health
by SDPhantom
https://www.wowinterface.com/forums/member.php?u=34145
===============================================================================

All Rights Reserved - Use at your own risk
UnZip contents into the "Interface\AddOns" folder in your WoW instalation directory

API Usage:
	RealMobHealth.RegisterHealthUpdateCallback(callback)
		[function]	callback	Callback function to run when a health update occurs
			functionCreatureKey, MaxHealth)
				[string/nil]	CreatureKey	Unique identifier for a creature
				[number/nil]	MaxHealth	Maximum health recorded for creature
			Note: MaxHealth will be nil if a creature entry is deleted.
			[Unused specification] All arguments are nil if multiple entries are affected

	RealMobHealth.UnregisterHealthUpdateCallback(callback)
		Unregisters callback function for health updates

	RealMobHealth.IsHealthUpdateCallbackRegistered(callback)
		Checks if callback function is registered for health updates

	RealMobHealth.GetUnitCreatureKey(unit)
		Returns the creature key for a given unit

	RealMobHealth.IsMobGUID(guid)
	RealMobHealth.IsUnitMob(unit)
		Checks if unit/guid is a Mob, NPC, or Rare

	RealMobHealth.GetUnitCreatureKey(unit)
		Returns the CreatureKey for a unit

	RealMobHealth.GetUnitHealth(unit[, speculate])
		[string] unit		Unit to query health for
		[bool] speculate	Enables speculation for max health (calculation based off percentage and damage taken) [default: false]
	Returns:	currenthealth, maxhealth, currentisspeculated, maxisspeculated
		[number] currenthealth	Current calculated health based on damage taken
		[number] maxhealth	Max health, prefers to return recorded over speculated
		[bool/nil] currentisspeculated	true if currenthealth is based off percentage instead of damage taken
		[bool/nil] maxisspeculated	true if maxhealth is based off percentage and damage taken
	Note: If there isn't enough data to calculate real health, the native values are returned and both booleans will be nil

	RealMobHealth.DeleteUnitHealthData(unit)
		Deletes unit's health data

	RealMobHealth.UnitHasHealthData(unit)
		Checks if unit has health recorded
===============================================================================

Versions:
1.1	(2019-06-05)
	-Streamlined the core code
	-Fixed issue with Shaman totems getting recorded
	-World/Raid bosses are now supported
	-Damage reflection is now properly tallied
	-More API functions, see above
	-RealMobHealth.GetHealth() had been renamed RealMobHealth.GetUnitHealth()
	-RealMobHealth.GetUnitHealth() now falls back to native values if not enough data present
	-Blizzard UI modifications are broken out into its own addon (RMH_BlizzardUI)

1.0	(2019-05-19)
	-Classic release
	-Records damage taken of nearby mobs from the CombatLog
	-Obtains mob level using mouseover/target/partytarget/raidtarget and if enabled, nameplates
	-TargetFrame and Nameplates show text values for health, TargetFrame also shows mana/rage/energy
	-Gametooltip shows which mobs have had their health recorded
