--[[tullaRange Config Localization - German]]

if GetLocale() ~= 'deDE' then return end

local AddonName, Addon = ...
local L = Addon.L

L.ColorSettings = 'Farben'

L.ColorSettingsTitle = 'Hier kannst du Farbeinstellungen vornehmen'

L.oor = 'Außer Reichweite'

L.oom = 'Nicht genug Mana'

L.unusable = 'Nicht benutzbar'

L.Red = 'Rot'

L.Green = 'Grün'

L.Blue = 'Blau'
