--[[tullaRange Config Localization - Italian]]

if GetLocale() ~= 'itIT' then return end

local AddonName, Addon = ...
local L = Addon.L

L.ColorSettings = 'Colori'

L.ColorSettingsTitle = 'Impostazioni per la configurazione del colore'

L.oor = 'Bersaglio distante'

L.oom = 'Mana scarso'

L.unusable = 'Non utilizzabile'

L.Red = 'Rosso'

L.Green = 'Verde'

L.Blue = 'Blu'
