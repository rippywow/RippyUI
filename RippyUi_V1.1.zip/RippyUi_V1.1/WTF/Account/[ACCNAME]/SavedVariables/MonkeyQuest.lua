
MonkeyQuestConfig = {
	["Classic Realm 15|Rip"] = {
		["m_aQuestList"] = {
			["Wild Fires in the Eastern Kingdoms - false"] = {
				["m_bChecked"] = true,
			},
			["Hidden Enemies - false"] = {
				["m_bChecked"] = true,
			},
			["Ragefire Chasm - true"] = {
				["m_bChecked"] = true,
			},
			["Orgrimmar - true"] = {
				["m_bChecked"] = true,
			},
			["The Power to Destroy... - false"] = {
				["m_bChecked"] = true,
			},
			["Slaying the Beast - false"] = {
				["m_bChecked"] = true,
			},
			["Wild Fires in Kalimdor - false"] = {
				["m_bChecked"] = true,
			},
			["Midsummer - true"] = {
				["m_bChecked"] = true,
			},
		},
	},
	["Classic Realm 15|Ripx"] = {
		["m_aQuestList"] = {
			["The Damned - false"] = {
				["m_bChecked"] = true,
			},
			["Deathknell - true"] = {
				["m_bChecked"] = true,
			},
			["A Rogue's Deal - false"] = {
				["m_bChecked"] = true,
			},
			["Tirisfal Glades - true"] = {
				["m_bChecked"] = true,
			},
			["The Mindless Ones - false"] = {
				["m_bChecked"] = true,
			},
			["Fields of Grief - false"] = {
				["m_bChecked"] = true,
			},
		},
	},
	["Global"] = {
		["m_bItemsEnabled"] = true,
		["m_iFont"] = 0,
		["m_strHeaderClosedColour"] = "|cFF9F9FFF",
		["m_strSpecialObjectiveColour"] = "|cFFFFFF00",
		["m_iFrameAlpha"] = 1,
		["m_bColourTitle"] = false,
		["m_strAnchor"] = "ANCHOR_TOPLEFT",
		["m_bAllowRightClick"] = true,
		["m_strZoneHighlightColour"] = "|cff494961",
		["m_strFinishObjectiveColour"] = "|cffeefffa",
		["m_bShowHidden"] = false,
		["m_bItemsOnLeft"] = false,
		["m_bShowNoobTips"] = true,
		["m_bHideCompletedObjectives"] = true,
		["m_bShowZoneHighlight"] = true,
		["m_strCompleteObjectiveColour"] = "|cff 0ff19",
		["m_bAlwaysHeaders"] = false,
		["m_bDisplay"] = true,
		["m_bMinimized"] = false,
		["m_strInitialObjectiveColour"] = "|cFFD82619",
		["m_iHighlightAlpha"] = 1,
		["m_bShowQuestLevel"] = false,
		["m_bShowDailyNumQuests"] = false,
		["m_bDefaultAnchor"] = false,
		["m_iFrameBottom"] = 658.999938964844,
		["m_bHideCompletedQuests"] = false,
		["m_bLocked"] = true,
		["m_bNoBorder"] = true,
		["m_bNoHeaders"] = false,
		["m_iFrameLeft"] = 1413.33349609375,
		["m_strOverviewColour"] = "|cFF7F7F7F",
		["m_bColourSubObjectivesByProgress"] = true,
		["m_bShowTooltipObjectives"] = true,
		["m_strMidObjectiveColour"] = "|cFFFFFF00",
		["m_iFontHeight"] = 13,
		["m_strQuestTitleColour"] = "|cffffe2 0",
		["m_bWorkComplete"] = false,
		["m_bHideQuestsEnabled"] = true,
		["m_iFrameWidth"] = 300,
		["m_bCrashBorder"] = true,
		["m_strHeaderOpenColour"] = "|cFFBFBFFF",
		["m_iFrameTop"] = 885.666564941406,
		["m_bObjectives"] = false,
		["m_bHideHeader"] = true,
		["m_bShowNumQuests"] = true,
		["m_iAlpha"] = 0,
		["m_iQuestPadding"] = 0,
		["m_bHideTitle"] = true,
		["m_bHideTitleButtons"] = false,
		["m_bGrowUp"] = true,
	},
	["Stalagg|Rippyui"] = {
		["m_aQuestList"] = {
			["The Damned - false"] = {
				["m_bChecked"] = true,
			},
			["Deathknell - true"] = {
				["m_bChecked"] = true,
			},
			["Night Web's Hollow - false"] = {
				["m_bChecked"] = true,
			},
			["Rattling the Rattlecages - false"] = {
				["m_bChecked"] = true,
			},
			["Marla's Last Wish - false"] = {
				["m_bChecked"] = true,
			},
			["Scavenging Deathknell - false"] = {
				["m_bChecked"] = true,
			},
		},
	},
	["Classic Realm 15|Rippy"] = {
		["m_aQuestList"] = {
			["The Damned - false"] = {
				["m_bChecked"] = true,
			},
			["Deathknell - true"] = {
				["m_bChecked"] = true,
			},
			["A Rogue's Deal - false"] = {
				["m_bChecked"] = true,
			},
			["Rude Awakening - false"] = {
				["m_bChecked"] = true,
			},
			["The Mindless Ones - false"] = {
				["m_bChecked"] = true,
			},
		},
	},
	["Stalagg|Rippy"] = {
		["m_aQuestList"] = {
		},
	},
	["Blaumeux|Rippy"] = {
		["m_aQuestList"] = {
			["The Damned - false"] = {
				["m_bChecked"] = true,
			},
			["Deathknell - true"] = {
				["m_bChecked"] = true,
			},
			["Rattling the Rattlecages - false"] = {
				["m_bChecked"] = true,
			},
		},
	},
}
