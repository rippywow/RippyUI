
KuiNameplatesCoreSaved = {
	["216_HEALTH_TRANSITION"] = true,
	["2162_PERSONAL_FRAME_SIZE_TRANSITION"] = true,
	["profiles"] = {
		["default"] = {
			["frame_height"] = 22,
			["font_size_small"] = 12,
			["font_size_normal"] = 14,
			["target_glow_colour"] = {
				1, -- [1]
				0, -- [2]
				0, -- [3]
				0.596078431372549, -- [4]
			},
			["target_glow"] = false,
			["bar_animation"] = 2,
			["auras_show_all_self"] = true,
			["font_style"] = 4,
			["execute_enabled"] = false,
		},
	},
}
