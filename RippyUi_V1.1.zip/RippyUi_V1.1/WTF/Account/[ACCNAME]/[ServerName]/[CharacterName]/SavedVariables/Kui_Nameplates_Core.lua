
KuiNameplatesCoreCharacterSaved = {
	["profile"] = "default",
}
