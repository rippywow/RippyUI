
characterSettings = {
	["FrameScale"] = "1.3",
}
