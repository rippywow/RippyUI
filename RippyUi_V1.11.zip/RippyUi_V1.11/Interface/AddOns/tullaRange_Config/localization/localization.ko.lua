if GetLocale() ~= 'koKR' then return end

local AddonName, Addon = ...
local L = Addon.L

L.ColorSettings = '색상'

L.ColorSettingsTitle = 'tullaRange 색상 구성 설정'

L.oor = '사정거리 벗어남'

L.oom = '마나 부족'

L.unusable = '사용불가'

L.Red = '빨강'

L.Green = '녹색'

L.Blue = '파랑'
