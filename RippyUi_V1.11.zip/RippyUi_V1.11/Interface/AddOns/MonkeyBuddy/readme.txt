MonkeyBuddy slash commands:

/monkeybuddydismiss
/mbdismiss
Sends the MonkeyBuddy icon away :(

/monkeybuddycall
/mbcall
Calls the MonkeyBuddy icon back :)
