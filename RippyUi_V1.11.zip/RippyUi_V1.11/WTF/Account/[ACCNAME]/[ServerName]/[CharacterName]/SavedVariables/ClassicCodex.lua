
CodexHistory = {
	[376] = true,
	[363] = true,
	[364] = true,
	[3098] = true,
	[3901] = true,
}
