
LeaMapsDB = {
	["MainPanelA"] = "CENTER",
	["MainPanelX"] = 0,
	["RevTint"] = "Off",
	["ShowIcons"] = "On",
	["RevealMap"] = "On",
	["MainPanelR"] = "CENTER",
	["MainPanelY"] = 0,
}
