
OneBag3DB = {
	["namespaces"] = {
		["SimpleSort"] = {
		},
	},
	["profileKeys"] = {
		["Rippy - Stalagg"] = "Rippy - Stalagg",
		["Ripx - Classic Realm 15"] = "Ripx - Classic Realm 15",
		["Rip - Classic Realm 15"] = "Rip - Classic Realm 15",
		["Rippyui - Stalagg"] = "Rippyui - Stalagg",
		["Rippy - Classic Realm 15"] = "Rippy - Classic Realm 15",
		["Rippy - Blaumeux"] = "Rippy - Blaumeux",
	},
	["profiles"] = {
		["Rippy - Stalagg"] = {
		},
		["Ripx - Classic Realm 15"] = {
			["position"] = {
				["top"] = 279,
				["left"] = 931,
			},
			["moved"] = true,
		},
		["Rip - Classic Realm 15"] = {
			["position"] = {
				["top"] = 328,
				["left"] = 1101.6669921875,
			},
			["colors"] = {
				["mouseover"] = {
					["g"] = 0.701960784313726,
				},
				["background"] = {
					["a"] = 1,
				},
			},
			["appearance"] = {
				["scale"] = 0.9,
				["lowlevel"] = true,
			},
			["moved"] = true,
		},
		["Rippyui - Stalagg"] = {
			["position"] = {
				["top"] = 243.33317565918,
				["left"] = 1322.66650390625,
			},
			["moved"] = true,
		},
		["Rippy - Classic Realm 15"] = {
		},
		["Rippy - Blaumeux"] = {
			["moved"] = true,
			["appearance"] = {
				["scale"] = 1.15,
			},
			["position"] = {
				["top"] = 228.840744018555,
				["left"] = 1096.75366210938,
			},
		},
	},
}
