
globalSettings = nil
