
ClassicCastbarsDB = {
	["locale"] = "enUS",
	["version"] = "5",
	["target"] = {
		["enabled"] = true,
		["showTimer"] = false,
		["showSpellRank"] = false,
		["castBorder"] = "",
		["castFont"] = "Fonts\\FRIZQT__.TTF",
		["simpleStyle"] = false,
		["showCastInfoOnly"] = false,
		["width"] = 150,
		["castStatusBar"] = "Interface\\AddOns\\Kui_Media\\t\\bar-bright",
		["position"] = {
			"CENTER", -- [1]
			-10.2, -- [2]
			-87, -- [3]
		},
		["height"] = 15,
		["iconSize"] = 16,
		["autoPosition"] = false,
		["castFontSize"] = 13,
	},
	["nameplate"] = {
		["enabled"] = true,
		["showTimer"] = false,
		["showSpellRank"] = false,
		["castBorder"] = "Interface\\Tooltips\\UI-Tooltip-Border",
		["castFont"] = "Fonts\\FRIZQT__.TTF",
		["simpleStyle"] = true,
		["showCastInfoOnly"] = false,
		["width"] = 98.1,
		["castStatusBar"] = "Interface\\TargetingFrame\\UI-StatusBar",
		["position"] = {
			"CENTER", -- [1]
			0.2, -- [2]
			-23.1, -- [3]
		},
		["height"] = 14.1,
		["iconSize"] = 14,
		["autoPosition"] = true,
		["castFontSize"] = 10,
	},
	["pushbackDetect"] = false,
}
