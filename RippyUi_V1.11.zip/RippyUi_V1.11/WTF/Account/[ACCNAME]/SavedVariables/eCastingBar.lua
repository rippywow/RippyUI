
eCastingBar_Settings = {
	["rippy"] = {
		["FontSize"] = 16,
		["MirrorEnabled"] = 0,
		["Left"] = 764,
		["SuccessColor"] = {
			0, -- [1]
			0.329411764705882, -- [2]
			1, -- [3]
			1, -- [4]
		},
		["FlashBorderColor"] = {
			0.258823529411765, -- [1]
			1, -- [2]
			0.976470588235294, -- [3]
			1, -- [4]
		},
		["MirrorUseFlightTimer"] = 1,
		["ShowTime"] = 1,
		["Texture"] = "Smooth",
		["ChannelColor"] = {
			0.3, -- [1]
			0.3, -- [2]
			1, -- [3]
			1, -- [4]
		},
		["MirrorHeight"] = 26,
		["FeignDeathColor"] = {
			1, -- [1]
			0.7, -- [2]
			0, -- [3]
			1, -- [4]
		},
		["Bottom"] = 169,
		["MirrorHideBorder"] = 0,
		["MirrorWidth"] = 264,
		["Alpha"] = 100,
		["Width"] = 284,
		["HideBorder"] = 0,
		["MirrorFontSize"] = 12,
		["ExhaustionColor"] = {
			1, -- [1]
			0.9, -- [2]
			0, -- [3]
			1, -- [4]
		},
		["MirrorLeft"] = 775,
		["ShowSpellRank"] = 1,
		["MirrorAlpha"] = 100,
		["IconPosition"] = "HIDDEN",
		["MirrorBottom"] = 600,
		["Locked"] = 1,
		["BreathColor"] = {
			0, -- [1]
			0.5, -- [2]
			1, -- [3]
			1, -- [4]
		},
		["Enabled"] = 1,
		["MirrorLocked"] = 0,
		["MirrorTimeColor"] = {
			1, -- [1]
			1, -- [2]
			1, -- [3]
			1, -- [4]
		},
		["SpellColor"] = {
			0, -- [1]
			0.737254901960784, -- [2]
			1, -- [3]
			1, -- [4]
		},
		["ShowSpellName"] = 1,
		["MirrorShowTime"] = 1,
		["MirrorTexture"] = "Perl",
		["ShowDelay"] = 1,
		["FlightColor"] = {
			0.26, -- [1]
			0.93, -- [2]
			1, -- [3]
			1, -- [4]
		},
		["FailedColor"] = {
			1, -- [1]
			0, -- [2]
			0, -- [3]
			1, -- [4]
		},
		["MirrorFlashBorderColor"] = {
			1, -- [1]
			0.88, -- [2]
			0.25, -- [3]
			1, -- [4]
		},
		["Height"] = 32,
		["MirrorShowTimerLabel"] = 1,
		["DelayColor"] = {
			1, -- [1]
			0, -- [2]
			0, -- [3]
			1, -- [4]
		},
		["TimeColor"] = {
			1, -- [1]
			1, -- [2]
			1, -- [3]
			1, -- [4]
		},
	},
}
